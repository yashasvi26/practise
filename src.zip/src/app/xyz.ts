export interface list {
  id: string,
  title: string,
  year: string,
  author: string
}
