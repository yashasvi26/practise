import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'componentinteraction';
  id:number = null;name:string="";sal:number=null;dept:string="";

  id1 = "";
  name1="";
  sal1 = "";
  dept1 = "";
  index = "";

  users:any=[
    {id:1001, name:"rahul", sal:90000, dept:"java"},
    {id:1002, name:"sachin", sal:40000, dept:"java"},
    {id:1003, name:"vikas", sal:29000, dept:"java"}

  ];

  change()
  {
    let obj={id: this.id, name: this.name, sal: this.sal, dept: this.dept};
    this.users.push(obj);
  }

  delete(delid)
  {
    this.users.splice(this.users.indexOf(delid), 1);
  }

  update(e)
  {
    this.id1 = e.id;
    this.name1 = e.name;
    this.sal1 = e.sal;
    this.dept1 = e.dept;

    this.index = this.users.indexOf(e);
  }

  updated()
  {
    let obj1={id: this.id1, name: this.name1, sal: this.sal1, dept: this.dept1};
    this.users.splice(this.index, 1, obj1);
  }



}
