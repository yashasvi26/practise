import { Injectable } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/Http';


@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http: HttpClient) { }

  getData() {
    return this.http.get('../assets/booklist.json');
  }
}
