import { Component } from '@angular/core';
import { BookService } from './services/book.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'componentinteraction';
  term1 = '';
  term2 = '';
  term3 = '';
  term4 = '';
  jsonString;

  constructor(private ob: BookService) { }
  booksData;

  ngOnInit()
  {
    this.ob.getData().subscribe(data=>{this.booksData=data;});
  }




  idsort()
{
  this.booksData.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
}

titlesort()
{
  this.booksData.sort((a, b) => a.title < b.title ? -1 : a.title > b.title ? 1 : 0);
}

authorsort()
{
  this.booksData.sort((a, b) => a.author < b.author ? -1 : a.author > b.author ? 1 : 0);
}

yearsort()
{
  this.booksData.sort((a, b) => a.year < b.year ? -1 : a.year > b.year ? 1 : 0);
}

delete(i)
{
  this.booksData.splice(this.booksData.indexOf(i), 1);
}
}
