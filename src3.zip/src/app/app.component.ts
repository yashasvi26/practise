import { Component } from '@angular/core';
import { FormGroup, FormControl,FormBuilder,Validators} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // title = 'lab3';
  // formvar:FormGroup;
  // pid="";
  // name="";
  // cost="";
  // prod:any[]=[]
  ugabugbuga;
  category: string[] = [
    'Electronics',
    'Grocery',
    'Mobile',
    'Cloth'
  ];
  online:any[]=['Yes','No'];
  products:any[]=['BigBazar','D-Mart','Alliance','Mega Store'];
   userform: FormGroup; 
  // id: FormControl;
  // name: FormControl;
  // cost: FormControl;
  // radioControl: FormControl;
  // ponline:FormGroup;
  constructor(){}
  // constructor(private fb: FormBuilder) {}
  ngOnInit(){
    // this.userform = this.fb.group({
    //   id:'',
    //   name: ''  ,
    //   cost: '',
    //   category: '',
    //   online:'',
    //   products:''
    // })
  }
  validate(userforms){
    // if (this.userform) {
      console.log("Form Submitted!");
      
      console.log(userforms.value);
  // }
}
}