import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'componentinteraction';

list:any=[
{id:1001,name:'Rahul',sal:9000,dept:'JAVA',empjoiningdate:'6/12/2014'},
{id:1002,name:'Vikash',sal:11000,dept:'ORAAPS',empjoiningdate:'6/12/2017'},
{id:1003,name:'Uma',sal:12000,dept:'JAVA',empjoiningdate:'6/12/2010'},
{id:1004,name:'Sachin',sal:11500,dept:'ORAAPS',empjoiningdate:'11/12/2017'},
{id:1005,name:'Amol',sal:7000,dept:'.NET',empjoiningdate:'1/1/2018'},
{id:1006,name:'Vishal',sal:17000,dept:'BI',empjoiningdate:'9/12/2012'},
{id:1007,name:'Rajita',sal:21000,dept:'BI',empjoiningdate:'6/7/2014'},
{id:1008,name:'Neelima',sal:81000,dept:'TESTING',empjoiningdate:'6/17/2015'},
{id:1009,name:'Daya',sal:1000,dept:'TESTING',empjoiningdate:'6/17/2016'}
];


idsort()
{
  this.list.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
}

namesort()
{
  this.list.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
}

salsort()
{
  this.list.sort((a, b) => a.sal < b.sal ? -1 : a.sal > b.sal ? 1 : 0);
}

deptsort()
{
  this.list.sort((a, b) => a.dept < b.dept ? -1 : a.dept > b.dept ? 1 : 0);
}

joinsort()
{
  this.list.sort((a, b) => a.empjoiningdate < b.empjoiningdate ? -1 : a.empjoiningdate > b.empjoiningdate ? 1 : 0);
}


}
