import { Component, OnInit } from '@angular/core';
import { BookService } from 'D:/assignment/Angular/routing-dem/src/app/services/book.service';


@Component({
  selector: 'app-disp',
  templateUrl: './disp.component.html',
  styleUrls: ['./disp.component.css']
})
export class DispComponent implements OnInit {
  title = 'componentinteraction';
  term1 = '';
  term2 = '';
  term3 = '';
  term4 = '';
  jsonString;

  constructor(private ob: BookService) { }
  booksData;

  ngOnInit()
  {
    this.ob.getData().subscribe(data=>{this.booksData=data;});
  }


}
