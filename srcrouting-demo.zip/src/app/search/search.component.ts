import { Component, OnInit } from '@angular/core';
import { BookService } from 'D:/assignment/Angular/routing-dem/src/app/services/book.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private ob: BookService) { }
  booksData;

  ngOnInit()
  {
    this.ob.getData().subscribe(data=>{this.booksData=data;});
  }

  

 

}
